/* ==========================================================================
   POPULAR DRIVING SCHOOL - Premium Application Logic
   Features: Dynamic Language Engine (Bilingual EN/ZH), Black/White Theme Toggle,
             Smooth Scrolling, Booking Interaction, Form Validator, FAQ Accordion.
   ========================================================================== */

// Embedded localization database as a fail-safe (if translations.json is blocked by CORS file://)
const FALLBACK_TRANSLATIONS = {
  "en": {
    "nav_brand": "POPULAR DRIVING SCHOOL",
    "nav_brand_sub": "MTO APPROVED BDE PROVIDER",
    "nav_home": "Home",
    "nav_courses": "Courses & Packages",
    "nav_about": "About Us",
    "nav_registration": "Register",
    "nav_faq": "FAQ",
    "nav_contact": "Contact Us",
    "lang_toggle_label": "中文",
    "hero_tagline": "PROVINCE OF ONTARIO REGISTERED BDE COURSE PROVIDER",
    "hero_title": "Drive Safely, Pass Confidently",
    "hero_subtitle": "Ministry-Approved Beginner Driver Education (BDE). We assist you every step of the way—from learning how to drive to passing your G2/G tests and maintaining your car.",
    "hero_cta_register": "Register Online Now",
    "hero_cta_courses": "Explore Packages",
    "stat_pass_rate": "98%",
    "stat_pass_rate_desc": "First-Time Pass Rate",
    "stat_instructors": "MTO Certified",
    "stat_instructors_desc": "Professional Instructors",
    "stat_experience": "15+ Years",
    "stat_experience_desc": "Trusted Service",
    "alert_title": "🚨 SPECIAL ACCELERATED WINTER EXPRESS & OFFERS",
    "alert_text": "Register for our Accelerated BDE Course today! Save $50 on our Early Bird Special for upcoming Winter & Spring Break packages. Group discounts available for G + G2 complete bundles.",
    "info_section_title": "Important Ministry (MTO) Regulations",
    "info_section_subtitle": "Please read these mandatory requirements to successfully claim your BDE certificate.",
    "info_card_1_title": "1. Course Completion Time Limit",
    "info_card_1_desc": "The Ministry of Transportation (MTO) requires all students to complete all classroom, homework, and in-car training modules within ONE YEAR OF THE STARTING DATE. No exceptions are permitted by MTO.",
    "info_card_2_title": "2. Certification Requirements",
    "info_card_2_desc": "To qualify for official MTO certification, all students must complete at least 20 hours of classroom learning (or online BDE theory), 10 hours of homework learning links, and 10 hours of 1-on-1 practical in-car training.",
    "info_card_3_title": "3. Road Test Waiting Period Reduction",
    "info_card_3_desc": "Once our driving school certifies you on the MTO portal, you qualify to take your G2 road test early—in just 8 months instead of the standard 12 months. No manual Driver's Licence History search is required.",
    "courses_section_title": "Our Courses & Packages",
    "courses_section_subtitle": "Select a program designed to match your goals, experience level, and budget. All in-car training is one-on-one with dual-brake safety vehicles.",
    "course_popular_badge": "Most Popular",
    "course_best_value_badge": "Best Value",
    "course_1_title": "MTO Approved BDE Package",
    "course_1_desc": "Standard beginner driver curriculum. Mandatory for wait-time reduction and premium insurance discounts.",
    "course_1_price": "$649",
    "course_1_price_suffix": "+ HST",
    "course_1_feature_1": "20 Hours Digital Classroom / Online Theory",
    "course_1_feature_2": "10 Hours Home-link Learning Assignments",
    "course_1_feature_3": "10 Hours 1-on-1 Private In-Car Lessons",
    "course_1_feature_4": "Official Ministry of Transportation Certification",
    "course_1_feature_5": "Eligible for G2 Road Test in 8 Months",
    "course_1_feature_6": "Qualifies for Auto Insurance Premium Discount",
    "course_2_title": "G2 Test Complete Package",
    "course_2_desc": "Perfect package for G1 holders ready to practice and use the instructor's dual-brake car for their road test.",
    "course_2_price": "$399",
    "course_2_price_suffix": "+ HST",
    "course_2_feature_1": "5 Hours Private One-on-One Driving Practice",
    "course_2_feature_2": "Defensive driving & parking maneuvers",
    "course_2_feature_3": "Complete mock road test evaluation",
    "course_2_feature_4": "Use of Instructor's Dual-Brake Car for Road Test",
    "course_2_feature_5": "Pickup & dropoff service within local area",
    "course_2_feature_6": "Free scheduling assistance for road test",
    "course_3_title": "G Road Test Complete Package",
    "course_3_desc": "Tailored for G2 drivers seeking highway driving expertise and vehicle rental for the final G license exam.",
    "course_3_price": "$449",
    "course_3_price_suffix": "+ HST",
    "course_3_feature_1": "5 Hours Highway & High-Speed Practice",
    "course_3_feature_2": "Defensive lane switching, merges & exits",
    "course_3_feature_3": "Detailed breakdown of G test scoring criteria",
    "course_3_feature_4": "Use of Instructor's Dual-Brake Car for G Road Test",
    "course_3_feature_5": "Pickup & dropoff service included",
    "course_3_feature_6": "Express road test booking options available",
    "course_4_title": "Hourly Individual Lessons",
    "course_4_desc": "Flexible hourly training designed to refresh your skills, correct driving flaws, or practice specific elements.",
    "course_4_price": "$60",
    "course_4_price_suffix": "/ hour",
    "course_4_feature_1": "Fully customized one-on-one lesson plans",
    "course_4_feature_2": "Tailored to your weaknesses (Parallel parking, etc.)",
    "course_4_feature_3": "Dual-brake vehicle provided for optimal safety",
    "course_4_feature_4": "High-patience, fluent bilingual instructors",
    "course_4_feature_5": "Flexible scheduling to fit your availability",
    "course_4_feature_6": "Pay-as-you-go with no long-term commitment",
    "course_btn_select": "Book This Package",
    "about_title": "About Popular Driving School",
    "about_p1": "Established as a premier driving education institution, Popular Driving School has successfully trained thousands of safe, confident drivers across Ontario. Our mission is to go beyond merely helping you pass your road test; we build defensive driving habits that protect you on the road for life.",
    "about_p2": "All our instructors are certified by the province of Ontario, background-checked, and highly experienced. We take pride in our exceptionally high first-time pass rates and our patient, supportive learning environment.",
    "about_feat_1_title": "MTO Certified Professionals",
    "about_feat_1_desc": "Expert guidance from state-licensed, friendly, and bilingual driving instructors.",
    "about_feat_2_title": "High First-Time Pass Rate",
    "about_feat_2_desc": "Most of our students pass their G2 or G road tests on their very first attempt.",
    "about_feat_3_title": "Bilingual Training",
    "about_feat_3_desc": "Lessons are taught fluently in English, Mandarin, or Cantonese depending on your preference.",
    "register_section_title": "Quick Online Registration",
    "register_section_subtitle": "Start your journey today. Fill out this secure form and our registrar will contact you in under 24 hours to schedule your classes.",
    "form_name": "Full Name",
    "form_name_placeholder": "Enter your first and last name",
    "form_phone": "Phone Number",
    "form_phone_placeholder": "e.g., 416-555-0199",
    "form_email": "Email Address",
    "form_email_placeholder": "e.g., yourname@domain.com",
    "form_license": "Driver's License Number (G1/G2)",
    "form_license_placeholder": "e.g., D1234-56789-01234 (Optional)",
    "form_package": "Select Driving Package",
    "form_package_placeholder": "-- Choose a Course --",
    "form_lang": "Preferred Instruction Language",
    "form_lang_en": "English",
    "form_lang_zh_mandarin": "Mandarin (普通话)",
    "form_lang_zh_cantonese": "Cantonese (粤语)",
    "form_notes": "Additional Notes / Availability",
    "form_notes_placeholder": "Share any schedule preferences or special requests with us...",
    "form_submit": "Submit Registration",
    "form_success_msg": "Thank you! Your registration has been received successfully. We will call or text you shortly.",
    "form_error_msg": "Please fill in all required fields accurately.",
    "faq_title": "Frequently Asked Questions",
    "faq_subtitle": "Clear, direct answers regarding Ontario licensing requirements, course structure, and tests.",
    "faq_q1": "How long does it take to complete the BDE Course?",
    "faq_a1": "The classroom (online theory) takes 20 hours, plus 10 hours of homework. The practical training takes 10 hours in the car. You can complete all portions in a few weeks depending on your availability. However, MTO regulations mandate that the entire course must be fully completed within one year of your registration date.",
    "faq_q2": "What are the benefits of completing an MTO-Approved BDE course?",
    "faq_a2": "There are two major benefits: 1. You qualify to take your G2 road test early, in just 8 months instead of the standard 12 months. 2. You receive an official certificate recorded in the MTO database, which insurance companies recognize for premium discounts (often up to 10-25% off depending on your insurance provider).",
    "faq_q3": "Can I use the driving instructor's vehicle for my official road test?",
    "faq_a3": "Yes! Our G2 and G packages explicitly include using our dual-brake, fully-insured instructor vehicle for your road exam. Driving the same car you practiced in greatly boosts your confidence and control during the test. We also offer this as an add-on for our standard BDE package.",
    "faq_q4": "How do I claim my BDE Course Certificate after graduating?",
    "faq_a4": "Once you successfully complete all 40 hours of BDE training (20h theory, 10h home-link, 10h in-car), we will register your completion directly on the Ministry of Transportation database. You can pick up a hard copy of your Driver's Licence History (DLH) at any ServiceOntario location for a minor MTO fee, which serves as your official proof of BDE course completion for insurance purposes.",
    "contact_title": "Get In Touch",
    "contact_subtitle": "Have questions? Reach out to our helpful admin team. We are here to support your success.",
    "contact_info_phone": "Main Office Phone",
    "contact_info_email": "Official Email",
    "contact_info_address": "Main Office Address",
    "contact_info_hours": "Business Hours",
    "contact_hours_value": "Monday - Sunday: 9:00 AM - 8:00 PM",
    "footer_description": "Ministry-Approved Beginner Driver Education (BDE) Course Provider. Helping drivers build safe, defensive driving techniques for Ontario's roads.",
    "footer_links_title": "Quick Links",
    "footer_rights": "Popular Driving School. All rights reserved.",
    "footer_compliance": "This driving school is fully registered and approved as a BDE course provider by the Ministry of Transportation (MTO) of Ontario."
  },
  "zh": {
    "nav_brand": "大众驾驶学校",
    "nav_brand_sub": "安省交通部 MTO 注册批准驾驶学校",
    "nav_home": "首页",
    "nav_courses": "课程与套餐",
    "nav_about": "关于我们",
    "nav_registration": "在线报名",
    "nav_faq": "常见问题",
    "nav_contact": "联系我们",
    "lang_toggle_label": "English",
    "hero_tagline": "安大略省交通部 (MTO) 官方注册批准 BDE 课程提供商",
    "hero_title": "安全驾驶，一次通过",
    "hero_subtitle": "交通部核准的初学者驾照教育课程 (BDE)。为您提供全程贴心协助：从基本驾驶技巧，到顺利考取 G2/G 牌照，再到车辆保养和选购。",
    "hero_cta_register": "立即在线报名",
    "hero_cta_courses": "浏览特惠套餐",
    "stat_pass_rate": "98%",
    "stat_pass_rate_desc": "路考首次通过率",
    "stat_instructors": "MTO 认证",
    "stat_instructors_desc": "专业持牌教练团队",
    "stat_experience": "15+ 年",
    "stat_experience_desc": "深受学员信赖",
    "alert_title": "🚨 特別快班与寒假特惠活动",
    "alert_text": "寒假 BDE 4天特快班限时报名中！在12月1日前完成报名，即可享受早鸟特惠立减 $50。G + G2 全包组合套餐更有额外团体折扣！",
    "info_section_title": "安省交通部 (MTO) 重要规定说明",
    "info_section_subtitle": "为了顺利获得 BDE 毕业证书并激活路考减免期，请学员务必遵守以下规定：",
    "info_card_1_title": "1. 课程完成时限 (一年)",
    "info_card_1_desc": "安省交通部规定，所有学员必须自注册开课之日起的【一年内】完成所有理论课堂、课后作业和车上练车训练。逾期无效，交通部不设任何例外情况。",
    "info_card_2_title": "2. 证书取得要求",
    "info_card_2_desc": "要符合交通部官方认证资格，学员须完成至少：20小时线上理论教学、10小时家庭作业/学习链接、以及10小时一对一实际路面车上培训。",
    "info_card_3_title": "3. 提前参加路考资格",
    "info_card_3_desc": "驾校在 MTO 系统上为您注册完成 BDE 课程后，您即可提前至【8个月】参加 G2 路试（无需等待标准的12个月，亦不需前往打印驾驶历史档案）。",
    "courses_section_title": "专业驾驶培训套餐",
    "courses_section_subtitle": "我们为您提供多样化的课程方案，完美契合您的驾驶基础与预算。所有练车课程均为一对一教学，并配备副刹车安全保障车辆。",
    "course_popular_badge": "最受欢迎",
    "course_best_value_badge": "超值推荐",
    "course_1_title": "交通部批准 BDE 全套包",
    "course_1_desc": "标准新手驾驶课程。安省推荐，缩短路考等待期并可获得保费最高额度优惠折扣。",
    "course_1_price": "$649",
    "course_1_price_suffix": "+ HST",
    "course_1_feature_1": "20 小时数字化网络理论教学",
    "course_1_feature_2": "10 小时家庭作业/学习平台辅助 assignments",
    "course_1_feature_3": "10 小时一对一专业路面练车训练",
    "course_1_feature_4": "安大略省交通部官方系统认证 (BDE Certificate)",
    "course_1_feature_5": "考取 G2 的等待期由 12 个月缩短至 8 个月",
    "course_1_feature_6": "符合安省汽车保险保费优惠资格 (降保费)",
    "course_2_title": "G2 路考直通包",
    "course_2_desc": "专为已有 G1 驾照、需要进行考前针对性练习并租用教练车参加路面考试的学员设计。",
    "course_2_price": "$399",
    "course_2_price_suffix": "+ HST",
    "course_2_feature_1": "5 小时一对一考前强化及模拟考试",
    "course_2_feature_2": "包含平行泊车、倒车入库、防御性安全要点",
    "course_2_feature_3": "路面考点实景模拟与考官扣分点透彻解析",
    "course_2_feature_4": "提供教练双刹车车辆供 G2 正式路考使用",
    "course_2_feature_5": "指定区域内免费上门接送服务",
    "course_2_feature_6": "免费提供路考排期和考点预订协助",
    "course_3_title": "G 牌路考强化包",
    "course_3_desc": "专为 G2 持有者设计。专注高速驾驶技巧、变道切线，并包含 G 牌正式考试租车服务。",
    "course_3_price": "$449",
    "course_3_price_suffix": "+ HST",
    "course_3_feature_1": "5 小时高级高速公路及快速通道实操演练",
    "course_3_feature_2": "强化高速汇入、切线、出入口防御性驾驶",
    "course_3_feature_3": "深入解构 G 牌路试考核细则与高频扣分项",
    "course_3_feature_4": "提供教练双刹车车辆供 G 牌正式路考使用",
    "course_3_feature_5": "指定范围接送服务，省心省力",
    "course_3_feature_6": "提供快捷考位排期和加急通道辅导",
    "course_4_title": "单散钟/按小时练车",
    "course_4_desc": "弹性灵活的散钟培训。适合需要考前补钟、纠正驾驶恶习或针对特定薄弱项目突击强化的学员。",
    "course_4_price": "$60",
    "course_4_price_suffix": "/ 小时",
    "course_4_feature_1": "完全定制的一对一路面个性化授课方案",
    "course_4_feature_2": "针对痛点重点突击（如平行泊车、三点掉头）",
    "course_4_feature_3": "配备双刹车教练车，提供极致安全防护",
    "course_4_feature_4": "极具耐心、双语流利（国语/粤语/英语）教练团队",
    "course_4_feature_5": "弹性练车时间，完美契合您的日常作息",
    "course_4_feature_6": "现结现付，没有任何捆绑式长期消费压力",
    "course_btn_select": "选择此套餐并预约",
    "about_title": "关于大众驾驶学校",
    "about_p1": "大众驾驶学校是安省知名的专业汽车驾驶教育机构，多年来已成功帮助数千名学员在多伦多及周边地区安全、自信地驶入公路。我们的办学宗旨不仅仅是协助您轻松通过路考，更重要的是为您植入防御性驾驶的良好习惯，确保您与家人的终身行车安全。",
    "about_p2": "我们的所有教练均持有安大略省官方教练执照，经过严格的安全背景审查，教学经验极其丰富。我们以极高的首次路考通过率、耐心细致的双语教学以及亲切的辅导环境，在华人群体中赢得了卓越的口碑。",
    "about_feat_1_title": "MTO 官方认证教练",
    "about_feat_1_desc": "所有教练均持牌上岗，教学态度和蔼温和，沟通无障碍。",
    "about_feat_2_title": "极高路考通过率",
    "about_feat_2_desc": "科学精细的模拟考评，让大部分学员在首考中顺利通关。",
    "about_feat_3_title": "多语种无障碍授课",
    "about_feat_3_desc": "提供标准国语、流利粤语或纯正英语教学，满足不同需求。",
    "register_section_title": "在线极速报名通道",
    "register_section_subtitle": "开启安全驾驶的第一步！请在下方输入您的基本信息，我们的注册主任将在24小时内与您取得联系并排期练车。",
    "form_name": "姓名",
    "form_name_placeholder": "请输入您的中文或英文姓名",
    "form_phone": "联系电话",
    "form_phone_placeholder": "例如：416-555-0199",
    "form_email": "电子邮箱",
    "form_email_placeholder": "例如：yourname@domain.com",
    "form_license": "安省驾照号码 (G1 / G2)",
    "form_license_placeholder": "例如：D1234-56789-01234 (选填)",
    "form_package": "选择意向驾驶套餐",
    "form_package_placeholder": "-- 请选择适合您的课程套餐 --",
    "form_lang": "首选教练授课语言",
    "form_lang_en": "英语 (English)",
    "form_lang_zh_mandarin": "国语 (Mandarin)",
    "form_lang_zh_cantonese": "粤语 (Cantonese)",
    "form_notes": "其他备注 / 练车时间要求",
    "form_notes_placeholder": "请告诉我们您方便的练车时间或您的特殊要求...",
    "form_submit": "提交报名申请",
    "form_success_msg": "报名成功！我们已收到您的申请。我们的工作人员将很快与您致电或短信联系。",
    "form_error_msg": "请完整且准确地填写所有必填字段。",
    "faq_title": "常见疑难解答",
    "faq_subtitle": "关于安省驾照申领要求、BDE课程流程和路面考试的官方权威解答。",
    "faq_q1": "完成全套 BDE 课程大概需要多长时间？",
    "faq_a1": "在线理论部分为 20 小时（学员可自由掌握进度），课后作业 10 小时，路面实操练车为 10 小时。根据您的时间排期，最快可在几周内全部完成。但根据交通部规定，所有环节必须自注册之日起一年内全部完成，逾期需要重新缴费报名。",
    "faq_q2": "考取交通部批准的 BDE 证书有哪些核心好处？",
    "faq_a2": "主要有两大好处：1. 缩短考牌等待期：您的 G2 路试排期时间可以从标准的 12 个月缩短到 8 个月，大大节省时间。2. 保费打折：毕业后您的信息直接录入交通部数据库，购买汽车保险时，可获得保险公司提供的 10% 到 25% 不等的保费打折优惠。",
    "faq_q3": "在正式参加 G2 或 G 牌路考时，我可以使用教练车吗？",
    "faq_a3": "可以！我们的 G2 及 G 牌路考直通包中已经明确包含了一次使用教练双刹车汽车参加路考的服务。使用平日练车时最熟悉的车辆考试，不仅上手顺畅，更能极大程度地消除考试时的紧张感，帮助稳定发挥。",
    "faq_q4": "毕业后我如何领取我的 BDE 课程证书？",
    "faq_a4": "当您顺利完成全部 40 小时培训后，我们将直接在交通部官方系统上为您申报毕业。毕业信息是完全数字化的，无需纸质证书。如果您需要纸质凭证提供给保险公司，只需携带身份证件前往任何一家 ServiceOntario 网点，支付交通部的小额规费，打印一份您的“Driver's Licence History (驾驶历史档案)”即可，该档案即是您的官方认证凭证。",
    "contact_title": "联系大众驾校",
    "contact_subtitle": "有任何疑问？欢迎随时联系我们和蔼可亲的客服团队，我们将竭诚为您排忧解难。",
    "contact_info_phone": "办公室电话",
    "contact_info_email": "官方客服邮箱",
    "contact_info_address": "驾校总部办公地址",
    "contact_info_hours": "客服在线时间",
    "contact_hours_value": "周一至周日：早上 9:00 - 晚上 8:00",
    "footer_description": "安大略省交通部 (MTO) 官方注册批准的初学者驾驶教育 (BDE) 课程提供商。专注防御性驾驶，保障行车平安。",
    "footer_links_title": "快捷导航",
    "footer_rights": "大众驾驶学校。版权所有。",
    "footer_compliance": "本校系经安大略省交通部官方依法注册并许可执业的专业驾驶培训学校，所有教学大纲及课时标准均符合 MTO 法规要求。"
  }
};

// Main state store
let currentLang = "en";
let translations = FALLBACK_TRANSLATIONS;

// ==========================================================================
// Initialization & Lifecycle
// ==========================================================================
document.addEventListener("DOMContentLoaded", async () => {
  // 1. Initial Theme setup (default light, checking localStorage)
  initTheme();

  // 2. Initial Language setup
  await initLanguage();

  // 3. Setup event listeners
  setupMobileMenu();
  setupSmoothScrolling();
  setupFAQAccordion();
  setupPackageBookingHooks();
  setupFormSubmission();
  setupWhyChooseInteractive();
});

// ==========================================================================
// Theme Management (Black/White Reversible Theme)
// ==========================================================================
function initTheme() {
  const themeToggleBtn = document.getElementById("themeToggle");
  if (!themeToggleBtn) return;

  // Retrieve saved preference or default to light/white
  const savedTheme = localStorage.getItem("theme") || "light";
  document.documentElement.setAttribute("data-theme", savedTheme);
  updateThemeUI(savedTheme);

  themeToggleBtn.addEventListener("click", () => {
    const currentTheme = document.documentElement.getAttribute("data-theme");
    const newTheme = currentTheme === "dark" ? "light" : "dark";
    
    document.documentElement.setAttribute("data-theme", newTheme);
    localStorage.setItem("theme", newTheme);
    updateThemeUI(newTheme);
  });
}

function updateThemeUI(theme) {
  const themeLabel = document.getElementById("themeLabel");
  const sunIcon = document.getElementById("themeSunIcon");
  const moonIcon = document.getElementById("themeMoonIcon");

  if (theme === "dark") {
    if (themeLabel) themeLabel.textContent = currentLang === "zh" ? "白色模式" : "White Mode";
    if (sunIcon) sunIcon.style.display = "inline";
    if (moonIcon) moonIcon.style.display = "none";
  } else {
    if (themeLabel) themeLabel.textContent = currentLang === "zh" ? "黑色模式" : "Black Mode";
    if (sunIcon) sunIcon.style.display = "none";
    if (moonIcon) moonIcon.style.display = "inline";
  }
}

// ==========================================================================
// Language Translation Engine
// ==========================================================================
async function initLanguage() {
  const langToggleBtn = document.getElementById("langToggle");
  if (!langToggleBtn) return;

  // 1. Try to fetch external JSON config
  try {
    const res = await fetch("translations.json");
    if (res.ok) {
      translations = await res.json();
    } else {
      console.warn("Using fallback translation dictionary (Non-OK fetch response).");
    }
  } catch (err) {
    console.warn("Using fallback translation dictionary (Likely CORS file:// path constraint).", err);
  }

  // 2. Resolve target language (from localStorage or default)
  currentLang = localStorage.getItem("language") || "en";
  applyLanguage(currentLang);

  // 3. Set toggle listener
  langToggleBtn.addEventListener("click", () => {
    currentLang = currentLang === "en" ? "zh" : "en";
    localStorage.setItem("language", currentLang);
    applyLanguage(currentLang);
    
    // Update theme button label as its wording depends on language
    const currentTheme = document.documentElement.getAttribute("data-theme") || "light";
    updateThemeUI(currentTheme);
  });
}

function applyLanguage(lang) {
  // Update body tag typography structure
  if (lang === "zh") {
    document.body.classList.add("lang-zh");
    document.documentElement.setAttribute("lang", "zh-CN");
  } else {
    document.body.classList.remove("lang-zh");
    document.documentElement.setAttribute("lang", "en");
  }

  // Translate all DOM items with data-i18n
  document.querySelectorAll("[data-i18n]").forEach(element => {
    const key = element.getAttribute("data-i18n");
    if (translations[lang] && translations[lang][key]) {
      element.innerHTML = translations[lang][key];
    }
  });

  // Translate placeholders
  document.querySelectorAll("[data-i18n-placeholder]").forEach(element => {
    const key = element.getAttribute("data-i18n-placeholder");
    if (translations[lang] && translations[lang][key]) {
      element.setAttribute("placeholder", translations[lang][key]);
    }
  });

  // Update form dropdown options dynamically
  const packageSelect = document.getElementById("registerPackage");
  if (packageSelect && translations[lang]) {
    const options = packageSelect.options;
    options[0].text = translations[lang]["form_package_placeholder"];
    options[1].text = translations[lang]["course_1_title"] + " (" + translations[lang]["course_1_price"] + ")";
    options[2].text = translations[lang]["course_2_title"] + " (" + translations[lang]["course_2_price"] + ")";
    options[3].text = translations[lang]["course_3_title"] + " (" + translations[lang]["course_3_price"] + ")";
    options[4].text = translations[lang]["course_4_title"] + " (" + translations[lang]["course_4_price"] + ")";
  }
}

// ==========================================================================
// Interactive Mobile Navigation Menu
// ==========================================================================
function setupMobileMenu() {
  const mobileToggleBtn = document.getElementById("mobileToggle");
  const navMenu = document.getElementById("navMenu");
  const menuLinks = document.querySelectorAll(".nav-link");

  if (!mobileToggleBtn || !navMenu) return;

  mobileToggleBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    navMenu.classList.toggle("open");
    // Swap icon states
    mobileToggleBtn.innerHTML = navMenu.classList.contains("open") ? "✕" : "☰";
  });

  // Close when clicking any menu link
  menuLinks.forEach(link => {
    link.addEventListener("click", () => {
      navMenu.classList.remove("open");
      mobileToggleBtn.innerHTML = "☰";
    });
  });

  // Close when clicking outside header
  document.addEventListener("click", (e) => {
    if (navMenu.classList.contains("open") && !e.target.closest("header")) {
      navMenu.classList.remove("open");
      mobileToggleBtn.innerHTML = "☰";
    }
  });
}

// ==========================================================================
// Smooth scrolling for navigation anchors
// ==========================================================================
function setupSmoothScrolling() {
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener("click", function (e) {
      e.preventDefault();
      const targetId = this.getAttribute("href");
      if (targetId === "#") return;
      const targetEl = document.querySelector(targetId);
      if (targetEl) {
        // Compensate for fixed header height
        const offsetPosition = targetEl.offsetTop - 80;
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    });
  });
}

// ==========================================================================
// Interactive Accordion for FAQs
// ==========================================================================
function setupFAQAccordion() {
  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach(item => {
    const trigger = item.querySelector(".faq-trigger");
    const content = item.querySelector(".faq-content");

    if (!trigger || !content) return;

    trigger.addEventListener("click", () => {
      const isActive = item.classList.contains("active");
      
      // Close all other items first for pure accordion behavior
      faqItems.forEach(otherItem => {
        if (otherItem !== item) {
          otherItem.classList.remove("active");
          otherItem.querySelector(".faq-content").style.maxHeight = null;
        }
      });

      // Toggle this item
      if (isActive) {
        item.classList.remove("active");
        content.style.maxHeight = null;
      } else {
        item.classList.add("active");
        content.style.maxHeight = content.scrollHeight + "px";
      }
    });
  });
}

// ==========================================================================
// Course Card to Registration Form Hook Integration
// ==========================================================================
function setupPackageBookingHooks() {
  const selectBtns = document.querySelectorAll(".select-package-btn");
  const packageSelect = document.getElementById("registerPackage");

  selectBtns.forEach(btn => {
    btn.addEventListener("click", () => {
      const targetValue = btn.getAttribute("data-package");
      if (packageSelect) {
        packageSelect.value = targetValue;
      }
      
      // Smooth scroll down to registration section
      const registerSection = document.getElementById("register");
      if (registerSection) {
        const offsetPosition = registerSection.offsetTop - 80;
        window.scrollTo({
          top: offsetPosition,
          behavior: "smooth"
        });
      }
    });
  });
}

// ==========================================================================
// Custom Interactive Panel in "Why Choose Us" / "About"
// ==========================================================================
function setupWhyChooseInteractive() {
  const choiceButtons = document.querySelectorAll(".choice-btn");
  const interactiveIcon = document.getElementById("interactiveIcon");
  const interactiveTitle = document.getElementById("interactiveTitle");
  const interactiveText = document.getElementById("interactiveText");

  if (!interactiveIcon || !interactiveTitle || !interactiveText) return;

  const features = {
    "mto": {
      icon: "🏆",
      title_en: "MTO Certified Professionals",
      title_zh: "MTO 官方认证教练",
      desc_en: "Expert guidance from state-licensed, friendly, and patient driving instructors who specialize in defensive training.",
      desc_zh: "所有教练均持有安大略省交通部官方执照，并经过彻底的安全背景审查，教学温和耐心，重点辅导防御性行车技巧。"
    },
    "pass": {
      icon: "⚡",
      title_en: "High First-Time Pass Rate",
      title_zh: "极高路考通过率",
      desc_en: "Our scientific, step-by-step training system ensures that the majority of our students pass their G2/G road test on the first try.",
      desc_zh: "采用循序渐进的模块化教学与路考实景模拟评估，针对考点进行个性化指导，确保学员在第一次考试中即可顺利过关。"
    },
    "lang": {
      icon: "🗣️",
      title_en: "Bilingual Training",
      title_zh: "多语种无障碍授课",
      desc_en: "Lessons are taught fluently in English, Mandarin (普通话), or Cantonese (粤语) according to your learning preferences.",
      desc_zh: "为您提供无语言门槛的教学服务。教练熟练掌握国语、粤语以及流利英语，能够精准阐述安省复杂路规与指令。"
    }
  };

  choiceButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      // Toggle button selection state UI
      choiceButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");

      // Extract details
      const featureId = btn.getAttribute("data-feature");
      const feat = features[featureId];

      if (feat) {
        // Animate out
        interactiveIcon.parentElement.style.opacity = 0;
        interactiveIcon.parentElement.style.transform = "scale(0.95)";

        setTimeout(() => {
          // Update values
          interactiveIcon.textContent = feat.icon;
          interactiveTitle.textContent = currentLang === "zh" ? feat.title_zh : feat.title_en;
          interactiveText.textContent = currentLang === "zh" ? feat.desc_zh : feat.desc_en;

          // Animate back in
          interactiveIcon.parentElement.style.opacity = 1;
          interactiveIcon.parentElement.style.transform = "scale(1)";
        }, 200);
      }
    });
  });
}

// ==========================================================================
// Form Submission, Validation & Visual Feedback
// ==========================================================================
function setupFormSubmission() {
  const form = document.getElementById("registrationForm");
  const formSuccess = document.getElementById("formSuccess");
  const formError = document.getElementById("formError");

  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    // Reset feedback alerts
    if (formSuccess) formSuccess.style.display = "none";
    if (formError) formError.style.display = "none";

    // Standard Client-Side checks
    const name = document.getElementById("registerName").value.trim();
    const phone = document.getElementById("registerPhone").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const selectedPkg = document.getElementById("registerPackage").value;

    if (!name || !phone || !email || !selectedPkg) {
      if (formError) {
        formError.style.display = "block";
        formError.textContent = translations[currentLang]["form_error_msg"];
      }
      return;
    }

    // Success simulation
    if (formSuccess) {
      formSuccess.style.display = "block";
      formSuccess.textContent = translations[currentLang]["form_success_msg"];
      
      // Direct console log for debug
      console.log("Registration submitted: ", { name, phone, email, selectedPkg });
      
      // Fluid reset of the form
      form.reset();
    }
  });
}
